# Lucas Job Hunter AI

MVP executável para cadastro, login, vagas e análise ATS básica.

## Executar

```bash
cp .env.example .env
docker compose up --build
```

Acesse:

- Aplicação: http://localhost:3000
- API: http://localhost:8000
- Swagger: http://localhost:8000/docs

## Testes

```bash
docker compose exec backend pytest -q
```

## Publicar no GitHub

Crie um repositório vazio no GitHub e execute dentro desta pasta:

```bash
git remote add origin https://github.com/SEU_USUARIO/LucasJobHunterAI.git
git branch -M main
git push -u origin main
```

## Funcionalidades deste MVP

- Cadastro e login JWT
- Perfil do usuário autenticado
- Cadastro e listagem de vagas
- Análise ATS textual simples
- Frontend React
- PostgreSQL
- Docker Compose
- Testes automatizados
