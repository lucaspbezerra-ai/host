import React, { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import './styles.css'

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000'

function App() {
  const [health, setHealth] = useState('carregando...')
  const [jobs, setJobs] = useState([])
  const [ats, setAts] = useState(null)

  useEffect(() => {
    fetch(`${API}/health`).then(r => r.json()).then(d => setHealth(d.status)).catch(() => setHealth('offline'))
    fetch(`${API}/jobs`).then(r => r.json()).then(setJobs).catch(() => setJobs([]))
  }, [])

  async function analyze() {
    const response = await fetch(`${API}/ats/analyze`, {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        resume_text: 'Biólogo com experiência em laboratório, microbiologia, qualidade e gestão ambiental',
        job_description: 'Analista Ambiental com ISO 14001, licenciamento ambiental e gestão de resíduos'
      })
    })
    setAts(await response.json())
  }

  return <main>
    <header><h1>Lucas Job Hunter AI</h1><p>API: <strong>{health}</strong></p></header>
    <section className="cards">
      <article><h2>Vagas</h2><strong>{jobs.length}</strong></article>
      <article><h2>ATS</h2><strong>{ats ? `${ats.score}%` : '—'}</strong></article>
    </section>
    <section>
      <h2>Análise rápida</h2>
      <button onClick={analyze}>Executar análise ATS</button>
      {ats && <pre>{JSON.stringify(ats, null, 2)}</pre>}
    </section>
    <section><h2>Vagas cadastradas</h2>{jobs.length ? jobs.map(j => <article className="job" key={j.id}><h3>{j.title}</h3><p>{j.company} — {j.location}</p></article>) : <p>Nenhuma vaga cadastrada ainda. Use o Swagger para criar uma.</p>}</section>
  </main>
}

createRoot(document.getElementById('root')).render(<App />)
