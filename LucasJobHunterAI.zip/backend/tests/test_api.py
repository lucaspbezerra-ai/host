def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_register_login_and_me(client):
    register = client.post("/auth/register", json={
        "full_name": "Lucas Pachella",
        "email": "lucas@example.com",
        "password": "123456",
    })
    assert register.status_code == 201

    login = client.post("/auth/login", json={
        "email": "lucas@example.com",
        "password": "123456",
    })
    assert login.status_code == 200
    token = login.json()["access_token"]

    me = client.get("/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.status_code == 200
    assert me.json()["email"] == "lucas@example.com"


def test_jobs_and_ats(client):
    client.post("/auth/register", json={
        "full_name": "Lucas Pachella",
        "email": "lucas@example.com",
        "password": "123456",
    })
    token = client.post("/auth/login", json={
        "email": "lucas@example.com",
        "password": "123456",
    }).json()["access_token"]

    created = client.post("/jobs", headers={"Authorization": f"Bearer {token}"}, json={
        "title": "Analista Ambiental Jr",
        "company": "Empresa Verde",
        "location": "SP",
        "description": "Licenciamento ambiental, ISO 14001 e gestão de resíduos",
        "source": "manual",
        "url": "https://example.com/job",
    })
    assert created.status_code == 201
    assert client.get("/jobs").status_code == 200

    ats = client.post("/ats/analyze", json={
        "resume_text": "Biólogo com experiência em laboratório, qualidade e gestão ambiental",
        "job_description": "Gestão ambiental, qualidade, ISO 14001 e licenciamento ambiental",
    })
    assert ats.status_code == 200
    assert ats.json()["score"] > 0
