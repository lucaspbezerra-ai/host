import re

from fastapi import APIRouter
from pydantic import BaseModel, Field

router = APIRouter(prefix="/ats", tags=["ats"])

STOPWORDS = {"para", "com", "uma", "das", "dos", "que", "por", "the", "and", "this", "that"}


class ATSRequest(BaseModel):
    resume_text: str = Field(min_length=10)
    job_description: str = Field(min_length=10)


def keywords(text: str) -> set[str]:
    words = re.findall(r"[a-zA-ZÀ-ÿ0-9+#.]{3,}", text.lower())
    return {word for word in words if word not in STOPWORDS}


@router.post("/analyze")
def analyze(data: ATSRequest):
    resume = keywords(data.resume_text)
    job = keywords(data.job_description)
    matched = sorted(resume & job)
    missing = sorted(job - resume)
    score = round((len(matched) / len(job)) * 100, 2) if job else 0
    return {"score": score, "matched_keywords": matched, "missing_keywords": missing[:30]}
