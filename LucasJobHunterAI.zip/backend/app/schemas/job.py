from pydantic import BaseModel, ConfigDict


class JobCreate(BaseModel):
    title: str
    company: str
    location: str = ""
    description: str
    source: str = "manual"
    url: str = ""


class JobResponse(JobCreate):
    id: int
    model_config = ConfigDict(from_attributes=True)
